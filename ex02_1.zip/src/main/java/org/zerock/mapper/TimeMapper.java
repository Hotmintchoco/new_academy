package org.zerock.mapper;

public interface TimeMapper {
	public String getTime();
}

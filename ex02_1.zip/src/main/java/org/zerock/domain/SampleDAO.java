package org.zerock.domain;

import lombok.Data;

@Data
public class SampleDAO {
	private String name;
	private int age;
}
